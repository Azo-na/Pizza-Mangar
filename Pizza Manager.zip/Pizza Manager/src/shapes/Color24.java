package shapes;

import java.awt.Color;

public class Color24 {

    private Color colorOfVegetable;

    public Color getColor() {
        return colorOfVegetable;
    }

    public void setColor(Color UserColor) {
        this.colorOfVegetable = UserColor;
    }
}
